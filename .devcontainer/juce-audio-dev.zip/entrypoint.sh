#!/usr/bin/env bash
# Boots a headless X display + window manager, exposes it over VNC
# and noVNC, then hands off to CMD. Lets you SEE the JUCE editor
# (standalone target or a plugin host) from a browser at :6080.
set -euo pipefail

start_gui() {
  echo "[entrypoint] starting Xvfb on ${DISPLAY} (${SCREEN_GEOMETRY})"
  Xvfb "${DISPLAY}" -screen 0 "${SCREEN_GEOMETRY}" -nolisten tcp &
  sleep 1

  echo "[entrypoint] starting fluxbox"
  fluxbox >/dev/null 2>&1 &
  sleep 1

  echo "[entrypoint] starting x11vnc on :${VNC_PORT}"
  x11vnc -display "${DISPLAY}" -rfbport "${VNC_PORT}" \
         -forever -shared -nopw -quiet -bg

  echo "[entrypoint] starting noVNC on :${NOVNC_PORT} -> browse http://localhost:${NOVNC_PORT}/vnc.html"
  websockify --web=/usr/share/novnc "${NOVNC_PORT}" "localhost:${VNC_PORT}" \
         >/dev/null 2>&1 &
}

# Only bring up the GUI stack if a display isn't already provided.
if [[ "${ENABLE_GUI:-1}" == "1" ]]; then
  start_gui
else
  echo "[entrypoint] ENABLE_GUI=0, skipping headless X stack"
fi

exec "$@"
