# JUCE audio-plugin dev container (with Claude Code)

A ready-to-build environment for developing a C++ / JUCE 8 audio plugin with a
WebView GUI, plus Claude Code onboard for the heavy lifting, and a headless
X + noVNC stack so you can *see* the plugin editor from your browser.

## Layout
```
Dockerfile        # Ubuntu 24.04 + build toolchain + JUCE deps + Claude Code
entrypoint.sh     # boots Xvfb + fluxbox + x11vnc + noVNC
compose.yaml      # dev service, volume mounts, port forwarding, auth persistence
CMakeLists.txt    # JUCE via FetchContent, WebView editor, wraps existing DSP
CLAUDE.md         # project rules Claude Code loads every session
webui/            # the WebView editor (html/css/js), bundled into the binary
src/              # <-- put PluginProcessor.cpp, PluginEditor.cpp, your DSP here
```

## Quickstart
```bash
# 1. Match container UID/GID to your host to avoid mount permission issues
#    (edit compose.yaml args, or create a .env with USER_UID/USER_GID).

# 2. Build & start
docker compose up -d --build

# 3. Get a shell
docker compose exec dev bash

# 4. First time only: authenticate Claude Code (persists in a named volume)
claude          # follow the browser OAuth prompt

# 5. Let Claude drive, or build by hand:
cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

## Seeing the GUI
The Standalone target renders inside the container's headless display.
Open **http://localhost:6080/vnc.html**, then from the container shell run the
built standalone binary under `build/MyPlugin_artefacts/Standalone/`.

## Notes
- Claude Code auth and the JUCE FetchContent clone are cached in named volumes,
  so rebuilds are cheap and you log in once.
- The WebView UI previews in a plain browser too (it falls back to a stub when
  no JUCE host is present) — handy for fast CSS/layout iteration.
- On Linux the JUCE renderer is GL/software; the fast Direct2D path is
  Windows-only, so benchmark UI performance on your Windows target, not here.
