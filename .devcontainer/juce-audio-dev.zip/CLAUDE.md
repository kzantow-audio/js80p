# MyPlugin — project guide for Claude Code

## What this is
A C++ audio plugin (JUCE 8, VST3 + Standalone) with a WebView-based GUI.
An existing DSP engine is being wrapped into JUCE; the near-term goal is a
new, more usable GUI. Longer-term aim: a premium synth that beats Zebra 3
on usability and sound.

## Build & run
- Configure: `cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release`
- Build:     `cmake --build build`
- Standalone binary lands under `build/MyPlugin_artefacts/`.
- To see the GUI: launch the Standalone target; view it at
  `http://localhost:6080/vnc.html` (headless X is already running).
- Validate before committing a plugin change:
  run `pluginval` / `clap-validator` against the built artefact.

## Architecture rules
- **Keep DSP framework-agnostic.** The audio engine must not depend on JUCE.
  JUCE wraps it (`AudioProcessor`), it does not live inside JUCE types.
- **Real-time audio thread is sacred.** In `processBlock`: no allocation,
  no locks, no file/log I/O, no exceptions. Parameter reads are lock-free
  (atomics / `juce::AudioProcessorValueTreeState`).
- UI↔DSP communication is message-passing, not shared mutable state.
  WebView UI talks to the processor via JUCE's WebView relay bindings.
- Prefer `juce::dsp` SIMD and explicit vectorization in hot loops; verify
  with `-Rpass=loop-vectorize` (clang) rather than assuming.

## Code style
- Modern C++20, RAII, no raw `new`/`delete`. `const`-correct.
- Minimal and clean — strip complexity when a simpler form is equivalent.
- Run `clang-format` before committing. Keep `processBlock` allocation-free.

## Don't
- Don't add `-march=native` to shippable builds; use a baseline ISA +
  runtime dispatch for wider SIMD.
- Don't introduce heavyweight deps for the GUI; the WebView stack is enough.
- Don't touch auth/keys/config files.
