// UI <-> DSP bridge.
//
// JUCE 8 injects a global `window.__JUCE__` and provides a JS module
// (juce-framework-frontend) for typed parameter/event relays. To keep
// this file dependency-free and previewable in a plain browser, we
// feature-detect the relay and fall back to console logging.

const statusEl = document.getElementById("status");
const gainEl = document.getElementById("gain");
const gainReadout = document.getElementById("gainReadout");

const juce = window.__JUCE__ || null;

// A tiny shim: if JUCE's relay is present, use it; otherwise no-op.
function makeParam(id, onHostChange) {
  if (juce && juce.getSliderState) {
    const state = juce.getSliderState(id); // JUCE WebSliderRelay-backed
    state.valueChangedEvent.addListener(() => onHostChange(state.getNormalisedValue()));
    return {
      set: (v) => state.setNormalisedValue(v),
      get: () => state.getNormalisedValue(),
    };
  }
  // Standalone-in-browser fallback.
  let v = 0.5;
  return {
    set: (nv) => { v = nv; console.log(`[stub] ${id} = ${nv.toFixed(3)}`); },
    get: () => v,
  };
}

const gainParam = makeParam("gain", (v) => {
  gainEl.value = String(v);
  gainReadout.textContent = v.toFixed(2);
});

gainEl.addEventListener("input", () => {
  const v = parseFloat(gainEl.value);
  gainReadout.textContent = v.toFixed(2);
  gainParam.set(v);
});

statusEl.textContent = juce ? "connected to processor" : "preview mode (no host)";
